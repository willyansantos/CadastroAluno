﻿namespace MVC.ViewModel.Autenticacao
{
    using Cadastro;
    using System.ComponentModel.DataAnnotations;

    public class UsuarioViewModel : PessoaViewModel
    {
        public int UsuarioID { get; set; }

        [Display(Name = "Senha:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(10, ErrorMessage = "Máximo 10 caracteres!")]
        public string Senha { get; set; }
    }
}