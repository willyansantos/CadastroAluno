﻿namespace MVC.ViewModel.Cadastro
{
    using Domain.Util;
    using System;
    using System.ComponentModel.DataAnnotations;

    public class AlunoViewModel : PessoaViewModel
    {
        public AlunoViewModel() { }

        public int? PaiPessoaID { get; set; }
        public int? MaePessoaID { get; set; }
        public DateTime? DataCadastro { get; set; }

        [Display(Name = "Matricula:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(20, ErrorMessage = "Máximo 200 caracteres!")]
        public string Matricula { get; set; }

        [Display(Name = "Informar o pai:")]
        public bool InformarPai { get; set; }

        [Display(Name = "Informar a mae:")]
        public bool InformarMae { get; set; }

        public PessoaViewModel Pai { get; set; }
        public PessoaViewModel Mae { get; set; }

        public string TipoSexoDescricao => TipoSexo?.Descricao();
    }
}