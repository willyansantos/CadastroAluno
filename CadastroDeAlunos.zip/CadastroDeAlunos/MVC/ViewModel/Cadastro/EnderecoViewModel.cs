﻿namespace MVC.ViewModel.Cadastro
{
    using Domain.Entities.Cadastro;
    using Domain.Entities.Enum;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class EnderecoViewModel
    {
        public EnderecoViewModel()
        {
            Municipios = new List<Municipio>();
        }

        public int EnderecoID { get; set; }
        public string Action { get; set; }
        public string Controller { get; set; }
        public string UpdateTargetId { get; set; }

        [Display(Name = "Logradouro:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(200, ErrorMessage = "Máximo 200 caracteres!")]
        public string Logradouro { get; set; }

        [Display(Name = "Numero:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(15, ErrorMessage = "Máximo 15 caracteres!")]
        public string Numero { get; set; }

        [Display(Name = "Cep:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public string Cep { get; set; }

        [Display(Name = "Bairro:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(200, ErrorMessage = "Máximo 200 caracteres!")]
        public string Bairro { get; set; }

        [Display(Name = "Municipio:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public int MunicipioID { get; set; }
        public IEnumerable<Municipio> Municipios { get; set; }

        [Display(Name = "Complemento:"), StringLength(200, ErrorMessage = "Máximo 200 caracteres!")]
        public string Complemento { get; set; }

        [Display(Name = "Estado:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public EUnidadeFederativa UnidadeFederativaID { get; set; }

        public MunicipioViewModel Municipio { get; set; }
    }
}