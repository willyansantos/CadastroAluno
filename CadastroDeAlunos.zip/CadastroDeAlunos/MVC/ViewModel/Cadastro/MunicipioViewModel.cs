﻿namespace MVC.ViewModel.Cadastro
{
    using Domain.Entities.Enum;
    using Domain.Util;
    using System.ComponentModel.DataAnnotations;

    public class MunicipioViewModel
    {
        public int MunicipioID { get; set; }

        [Display(Name = "Nome:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(200, ErrorMessage = "Máximo 200 caracteres!")]
        public string Nome { get; set; }

        [Display(Name = "Estado:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public EUnidadeFederativa? UnidadeFederativaID { get; set; }

        public string UnidadeFederativaDescricao => UnidadeFederativaID?.Descricao();
    }
}