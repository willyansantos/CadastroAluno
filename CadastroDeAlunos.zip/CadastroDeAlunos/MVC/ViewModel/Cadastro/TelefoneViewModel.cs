﻿namespace MVC.ViewModel.Cadastro
{
    using Domain.Entities.Enum;
    using System.ComponentModel.DataAnnotations;

    public class TelefoneViewModel
    {
        public TelefoneViewModel() { }

        public int TelefoneID { get; set; }
        public string Action { get; set; }
        public string Controller { get; set; }

        [Display(Name = "Tipo do Telefone:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public ETipoTelefone? TipoTelefone { get; set; }

        [Display(Name = "DDD:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public string DDD { get; set; }

        [Display(Name = "Numero:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public string Numero { get; set; }

        [Display(Name = "Operadora:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public EOperadora? Operadora { get; set; }

        [Display(Name = "Contato:"), StringLength(100, ErrorMessage = "Máximo 100 caracteres!")]
        public string Contato { get; set; }
    }
}