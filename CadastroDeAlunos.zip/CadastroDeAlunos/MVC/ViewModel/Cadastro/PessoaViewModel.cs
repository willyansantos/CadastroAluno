﻿namespace MVC.ViewModel.Cadastro
{
    using Domain.Entities.Enum;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class PessoaViewModel
    {
        public PessoaViewModel()
        {
            Telefones = new List<TelefoneViewModel>();
            Enderecos = new List<EnderecoViewModel>();
        }

        public int PessoaID { get; set; }

        [Display(Name = "Nome:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(200, ErrorMessage = "Máximo 200 caracteres!")]
        public string Nome { get; set; }

        [Display(Name = "Rg:"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(10, ErrorMessage = "Máximo 10 caracteres!")]
        public string Rg { get; set; }

        [Display(Name = "Cpf:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public string Cpf { get; set; }

        [Display(Name = "E-mail"), Required(ErrorMessage = "Campo Obrigatorio!"), StringLength(80, ErrorMessage = "Máximo 80 caracteres!"),
            DataType(DataType.EmailAddress), EmailAddress(ErrorMessage = "E-mail inválido")]
        public string Email { get; set; }

        [Display(Name = "Data de Nascimento:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public DateTime? DataNascimento { get; set; }

        [Display(Name = "Sexo:"), Required(ErrorMessage = "Campo Obrigatorio!")]
        public ETipoSexo? TipoSexo { get; set; }

        [Display(Name = "Profissao:"), StringLength(100, ErrorMessage = "Máximo 100 caracteres!")]
        public string Profissao { get; set; }

        public List<EnderecoViewModel> Enderecos { get; set; }
        public List<TelefoneViewModel> Telefones { get; set; }
    }
}