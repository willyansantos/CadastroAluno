﻿namespace MVC.ViewModel.Grafico
{
    using Domain.Entities.Cadastro;
    using System.Collections.Generic;
    using System.Linq;

    public class GraficoViewModel
    {
        public List<KeyValuePair<string, List<Aluno>>> DadosAlunoPorMunicipio { get; set; }
        public IEnumerable<IGrouping<string, Aluno>> DadosAlunoPorDataHora { get; set; }
    }
}