﻿namespace MVC.App_Start
{
    using System.Web.Optimization;

    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include("~/Scripts/jquery-{version}.js", "~/Scripts/jquery.inputmask.bundle.js", "~/Scripts/i18n/grid.locale-pt-br.js", "~/Scripts/jquery-ui-1.8.11.js", "~/Scripts/jquery.jqGrid.src.js", "~/Scripts/jquery.unobtrusive-ajax.min.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include("~/Scripts/modernizr-*"));
            bundles.Add(new ScriptBundle("~/bundles/datepicker").Include("~/Scripts/jquery.datetimepicker.js"));
            bundles.Add(new StyleBundle("~/bundles/css").Include("~/Content/site.css", "~/Content/jquery.datetimepicker.css", "~/Content/jquery-ui.css", "~/Content/jquery.jqGrid/ui.jqgrid.css"));
        }
    }
}