﻿namespace MVC.AutoMapper
{
    using Domain.Entities.Autenticacao;
    using Domain.Entities.Cadastro;
    using global::AutoMapper;
    using ViewModel.Autenticacao;
    using ViewModel.Cadastro;
    using System.Linq;
    using static System.DateTime;
    using Domain.Entities;
    using Domain.Util;

    public class AutoMapperConfig
    {
        public static void CreateMappings()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.CreateMap<JQGridResult<Aluno>, JQGridResult<AlunoViewModel>>();
                cfg.CreateMap<JQGridResult<Municipio>, JQGridResult<MunicipioViewModel>>();
                cfg.CreateMap<Usuario, UsuarioViewModel>()
                    .ForMember(u => u.Nome, x => x.MapFrom(y => y.Pessoa.Nome))
                    .ForMember(u => u.Cpf, x => x.MapFrom(y => y.Pessoa.Cpf))
                    .ForMember(u => u.Email, x => x.MapFrom(y => y.Pessoa.Email));
                cfg.CreateMap<UsuarioViewModel, Usuario>()
                    .ForMember(x => x.Pessoa, y => y.MapFrom(z => new Pessoa
                    {
                        Cpf = z.Cpf,
                        DataNascimento = z.DataNascimento ?? MinValue,
                        Email = z.Email,
                        Nome = z.Nome,
                        Profissao = z.Profissao,
                        Rg = z.Rg,
                        TipoSexo = z.TipoSexo.HasValue ? ((int)z.TipoSexo) : 0,
                        Enderecos = z.Enderecos.Select(Mapper.Map<Endereco>).ToList(),
                        Telefones = z.Telefones.Select(Mapper.Map<Telefone>).ToList()
                    }));
                cfg.CreateMap<TelefoneViewModel, Telefone>();
                cfg.CreateMap<Telefone, TelefoneViewModel>();
                cfg.CreateMap<EnderecoViewModel, Endereco>();
                cfg.CreateMap<Endereco, EnderecoViewModel>();
                cfg.CreateMap<MunicipioViewModel, Municipio>();
                cfg.CreateMap<Municipio, MunicipioViewModel>();
                cfg.CreateMap<PessoaViewModel, Pessoa>();
                cfg.CreateMap<Pessoa, PessoaViewModel>();
                cfg.CreateMap<AlunoViewModel, Aluno>()
                    .ForMember(x => x.Pessoa, y => y.MapFrom(z => new Pessoa
                    {
                        Cpf = z.Cpf,
                        DataNascimento = z.DataNascimento ?? MinValue,
                        Email = z.Email,
                        Nome = z.Nome,
                        Profissao = z.Profissao,
                        Rg = z.Rg,
                        TipoSexo = z.TipoSexo.HasValue ? ((int)z.TipoSexo) : 0,
                        Enderecos = z.Enderecos.Select(Mapper.Map<Endereco>).ToList(),
                        Telefones = z.Telefones.Select(Mapper.Map<Telefone>).ToList()
                    }))
                    .ForMember(x => x.Mae, y =>
                    {
                        y.Condition(z => z.InformarMae);
                        y.MapFrom(z => z.Mae);
                    })
                    .ForMember(x => x.Pai, y =>
                    {
                        y.Condition(z => z.InformarPai);
                        y.MapFrom(z => z.Pai);
                    });
                cfg.CreateMap<Aluno, AlunoViewModel>()
                    .ForMember(x => x.Cpf, y => y.MapFrom(z => z.Pessoa.Cpf.FormatarCPF()))
                    .ForMember(x => x.DataNascimento, y => y.MapFrom(z => z.Pessoa.DataNascimento))
                    .ForMember(x => x.Email, y => y.MapFrom(z => z.Pessoa.Email))
                    .ForMember(x => x.Nome, y => y.MapFrom(z => z.Pessoa.Nome))
                    .ForMember(x => x.Profissao, y => y.MapFrom(z => z.Pessoa.Profissao))
                    .ForMember(x => x.Rg, y => y.MapFrom(z => z.Pessoa.Rg))
                    .ForMember(x => x.TipoSexo, y => y.MapFrom(z => z.Pessoa.TipoSexo))
                    .ForMember(x => x.DataCadastro, y => y.MapFrom(z => z.Pessoa.DataCadastro))
                    .ForMember(x => x.Enderecos, y => y.MapFrom(z => z.Pessoa.Enderecos.Select(Mapper.Map<EnderecoViewModel>).ToList()))
                    .ForMember(x => x.Telefones, y => y.MapFrom(z => z.Pessoa.Telefones.Select(Mapper.Map<TelefoneViewModel>).ToList()));
            });
        }
    }
}