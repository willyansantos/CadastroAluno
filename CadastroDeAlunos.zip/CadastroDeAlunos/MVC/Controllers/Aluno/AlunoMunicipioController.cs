﻿namespace MVC.Controllers.Aluno
{
    using Domain.Interfaces.Application.Cadastro;
    using Architecture;
    using System.Web.Mvc;

    public class AlunoMunicipioController : BaseController
    {
        private readonly IMunicipioApplicationService municipioApplicationService;

        public AlunoMunicipioController(IMunicipioApplicationService municipioApplicationService)
        {
            this.municipioApplicationService = municipioApplicationService;
        }

        public ActionResult Index()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return View();
        }
    }
}