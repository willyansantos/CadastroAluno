﻿namespace MVC.Controllers.Aluno
{
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Interfaces.Application.Cadastro;
    using global::AutoMapper;
    using Architecture;
    using ViewModel.Cadastro;
    using System.Web.Mvc;
    using System.Linq;

    public partial class AlunoController : BaseController
    {
        private readonly IAlunoApplicationService alunoApplicationService;

        public AlunoController(IAlunoApplicationService alunoApplicationService, IMunicipioApplicationService municipioApplicationService)
        {
            this.alunoApplicationService = alunoApplicationService;
            this.municipioApplicationService = municipioApplicationService;
        }

        public ActionResult Index()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return View();
        }

        public ActionResult Inserir()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            LimparDadosSessao();
            return View(new AlunoViewModel());
        }

        [HttpPost]
        public ActionResult Inserir(AlunoViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            alunoApplicationService.UsuarioLogado = UsuarioLogado;
            alunoApplicationService.Entidade = Mapper.Map<Aluno>(vm);
            AtribuirValoresDaSessao();
            alunoApplicationService.Inserir();
            EmitirMensagem(alunoApplicationService.ObterMensagens());

            if (alunoApplicationService.EstaValido)
            {
                LimparDadosSessao();
                return RedirectToAction("Index");
            }

            AtribuirValoresDaSessao(vm);
            return View(vm);
        }

        public JsonResult ObterJQGrid(JQGrid jqGrid)
        {
            JQGridResult<AlunoViewModel> result = Mapper.Map<JQGridResult<AlunoViewModel>>(alunoApplicationService.ObterJQGrid(jqGrid));
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ObterJQGridPorMunicipio(int id, JQGrid jqGrid)
        {
            JQGridResult<AlunoViewModel> result = Mapper.Map<JQGridResult<AlunoViewModel>>(alunoApplicationService.ObterJQGridPorMunicipio(id, jqGrid));
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        private void LimparDadosSessao()
        {
            Enderecos = null;
            EnderecosMae = null;
            EnderecosPai = null;
        }
        private void AtribuirValoresDaSessao(AlunoViewModel vm = null)
        {
            if (vm == null)
            {
                alunoApplicationService.Entidade.Pessoa.Enderecos = Enderecos.Select(Mapper.Map<Endereco>).ToList();
                alunoApplicationService.Entidade.Pessoa.Telefones = Telefones.Select(Mapper.Map<Telefone>).ToList();

                if (alunoApplicationService.Entidade.Mae != null)
                {
                    alunoApplicationService.Entidade.Mae.Enderecos = EnderecosMae.Select(Mapper.Map<Endereco>).ToList();
                    alunoApplicationService.Entidade.Mae.Telefones = TelefonesMae.Select(Mapper.Map<Telefone>).ToList();
                }

                if (alunoApplicationService.Entidade.Pai != null)
                {
                    alunoApplicationService.Entidade.Pai.Enderecos = EnderecosPai.Select(Mapper.Map<Endereco>).ToList();
                    alunoApplicationService.Entidade.Pai.Telefones = TelefonesPai.Select(Mapper.Map<Telefone>).ToList();
                }
            }
            else
            {
                vm.Enderecos = Enderecos;
                vm.Telefones = Telefones;

                if (vm.Mae != null) { vm.Mae.Enderecos = EnderecosMae; vm.Mae.Telefones = TelefonesMae; }
                if (vm.Pai != null) { vm.Pai.Enderecos = EnderecosPai; vm.Pai.Telefones = TelefonesPai; }
            }
        }
    }
}