﻿namespace MVC.Controllers.Aluno
{
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Entities.Enum;
    using Domain.Interfaces.Application.Cadastro;
    using global::AutoMapper;
    using MVC.ViewModel.Cadastro;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    public partial class AlunoController
    {
        private IMunicipioApplicationService municipioApplicationService;

        public ActionResult AdicionarEndereco(EnderecoViewModel vm)
        {
            if (Enderecos.Any(c => c.Cep == vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco já adicionado!", ETipoMensagem.INFORMATIVO) });

            var endereco = Mapper.Map<Endereco>(vm);
            if (!endereco.ValidarInserir())
                return AlertErro(endereco.mensagens);

            vm.Municipio = Mapper.Map<MunicipioViewModel>(municipioApplicationService.Obter(vm.MunicipioID));
            vm.Action = "RemoverEndereco";
            vm.Controller = "Aluno";
            Enderecos.Add(vm);
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", Enderecos);
        }

        public ActionResult RemoverEndereco(EnderecoViewModel vm)
        {
            if (Enderecos.All(c => c.Cep != vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco não encontrado!", ETipoMensagem.INFORMATIVO) });

            Enderecos.Remove(Enderecos.FirstOrDefault(c => c.Cep == vm.Cep && c.Numero == vm.Numero));
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", Enderecos);
        }

        public ActionResult AdicionarEnderecoMae(EnderecoViewModel vm)
        {
            if (EnderecosMae.Any(c => c.Cep == vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco já adicionado!", ETipoMensagem.INFORMATIVO) });

            var endereco = Mapper.Map<Endereco>(vm);
            if (!endereco.ValidarInserir())
                return AlertErro(endereco.mensagens);

            vm.Municipio = Mapper.Map<MunicipioViewModel>(municipioApplicationService.Obter(vm.MunicipioID));
            vm.Action = "RemoverEnderecoMae";
            vm.Controller = "Aluno";
            EnderecosMae.Add(vm);
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", EnderecosMae);
        }

        public ActionResult RemoverEnderecoMae(EnderecoViewModel vm)
        {
            if (EnderecosMae.All(c => c.Cep != vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco não encontrado!", ETipoMensagem.INFORMATIVO) });

            EnderecosMae.Remove(EnderecosMae.FirstOrDefault(c => c.Cep == vm.Cep && c.Numero == vm.Numero));
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", EnderecosMae);
        }

        public ActionResult AdicionarEnderecoPai(EnderecoViewModel vm)
        {
            if (EnderecosPai.Any(c => c.Cep == vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco já adicionado!", ETipoMensagem.INFORMATIVO) });

            var endereco = Mapper.Map<Endereco>(vm);
            if (!endereco.ValidarInserir())
                return AlertErro(endereco.mensagens);

            vm.Municipio = Mapper.Map<MunicipioViewModel>(municipioApplicationService.Obter(vm.MunicipioID));
            vm.Action = "RemoverEnderecoPai";
            vm.Controller = "Aluno";
            EnderecosPai.Add(vm);
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", EnderecosPai);
        }

        public ActionResult RemoverEnderecoPai(EnderecoViewModel vm)
        {
            if (EnderecosPai.All(c => c.Cep != vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco não encontrado!", ETipoMensagem.INFORMATIVO) });

            EnderecosPai.Remove(EnderecosPai.FirstOrDefault(c => c.Cep == vm.Cep && c.Numero == vm.Numero));
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", EnderecosPai);
        }

        public ActionResult Endereco()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Endereco/_Endereco.cshtml", new EnderecoViewModel());
        }

        private List<EnderecoViewModel> Enderecos
        {
            get
            {
                var lista = Session["EnderecosAluno"] as List<EnderecoViewModel>;
                if (lista == null)
                {
                    lista = new List<EnderecoViewModel>();
                    Session["EnderecosAluno"] = lista;
                }

                return lista;
            }
            set { Session["EnderecosAluno"] = value; }
        }
        private List<EnderecoViewModel> EnderecosMae
        {
            get
            {
                var lista = Session["EnderecosMaeAluno"] as List<EnderecoViewModel>;
                if (lista == null)
                {
                    lista = new List<EnderecoViewModel>();
                    Session["EnderecosMaeAluno"] = lista;
                }

                return lista;
            }
            set { Session["EnderecosMaeAluno"] = value; }
        }
        private List<EnderecoViewModel> EnderecosPai
        {
            get
            {
                var lista = Session["EnderecosPaiAluno"] as List<EnderecoViewModel>;
                if (lista == null)
                {
                    lista = new List<EnderecoViewModel>();
                    Session["EnderecosPaiAluno"] = lista;
                }

                return lista;
            }
            set { Session["EnderecosPaiAluno"] = value; }
        }
    }
}