﻿namespace MVC.Controllers.Aluno
{
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Entities.Enum;
    using Domain.Interfaces.Application.Cadastro;
    using global::AutoMapper;
    using ViewModel.Cadastro;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    public partial class AlunoController
    {
        private IMunicipioApplicationService municipioApplicationService;

        public ActionResult AdicionarEndereco(EnderecoViewModel vm)
        {
            if (enderecos.Any(c => c.Cep == vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco já adicionado!", ETipoMensagem.INFORMATIVO) });

            var endereco = Mapper.Map<Endereco>(vm);
            if (!endereco.ValidarInserir())
                return AlertErro(endereco.mensagens);

            vm.Municipio = Mapper.Map<MunicipioViewModel>(municipioApplicationService.Obter(vm.MunicipioID));
            vm.Action = "RemoverEndereco";
            vm.Controller = "Aluno";
            enderecos.Add(vm);
            return Enderecos();
        }
        public ActionResult RemoverEndereco(EnderecoViewModel vm)
        {
            if (enderecos.All(c => c.Cep != vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco não encontrado!", ETipoMensagem.INFORMATIVO) });

            enderecos.Remove(enderecos.FirstOrDefault(c => c.Cep == vm.Cep && c.Numero == vm.Numero));
            return Enderecos();
        }
        public ActionResult Endereco()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Aluno/_Endereco.cshtml", new EnderecoViewModel());
        }
        public ActionResult Enderecos()
        {
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", enderecos);
        }

        public ActionResult AdicionarEnderecoMae(EnderecoViewModel vm)
        {
            if (enderecosMae.Any(c => c.Cep == vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco já adicionado!", ETipoMensagem.INFORMATIVO) });

            var endereco = Mapper.Map<Endereco>(vm);
            if (!endereco.ValidarInserir())
                return AlertErro(endereco.mensagens);

            vm.Municipio = Mapper.Map<MunicipioViewModel>(municipioApplicationService.Obter(vm.MunicipioID));
            vm.Action = "RemoverEnderecoMae";
            vm.Controller = "Aluno";
            enderecosMae.Add(vm);
            return EnderecosMae();
        }
        public ActionResult RemoverEnderecoMae(EnderecoViewModel vm)
        {
            if (enderecosMae.All(c => c.Cep != vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco não encontrado!", ETipoMensagem.INFORMATIVO) });

            enderecosMae.Remove(enderecosMae.FirstOrDefault(c => c.Cep == vm.Cep && c.Numero == vm.Numero));
            return EnderecosMae();
        }
        public ActionResult EnderecoMae()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Aluno/Mae/_Endereco.cshtml", new EnderecoViewModel());
        }
        public ActionResult EnderecosMae()
        {
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", enderecosMae);
        }

        public ActionResult AdicionarEnderecoPai(EnderecoViewModel vm)
        {
            if (enderecosPai.Any(c => c.Cep == vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco já adicionado!", ETipoMensagem.INFORMATIVO) });

            var endereco = Mapper.Map<Endereco>(vm);
            if (!endereco.ValidarInserir())
                return AlertErro(endereco.mensagens);

            vm.Municipio = Mapper.Map<MunicipioViewModel>(municipioApplicationService.Obter(vm.MunicipioID));
            vm.Action = "RemoverEnderecoPai";
            vm.Controller = "Aluno";
            enderecosPai.Add(vm);
            return EnderecosPai();
        }
        public ActionResult RemoverEnderecoPai(EnderecoViewModel vm)
        {
            if (enderecosPai.All(c => c.Cep != vm.Cep && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Endereco não encontrado!", ETipoMensagem.INFORMATIVO) });

            enderecosPai.Remove(enderecosPai.FirstOrDefault(c => c.Cep == vm.Cep && c.Numero == vm.Numero));
            return EnderecosPai();
        }
        public ActionResult EnderecoPai()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Aluno/Pai/_Endereco.cshtml", new EnderecoViewModel());
        }
        public ActionResult EnderecosPai()
        {
            return PartialView("~/Views/Endereco/_Enderecos.cshtml", enderecosPai);
        }

        private List<EnderecoViewModel> enderecos
        {
            get
            {
                var lista = Session["EnderecosAluno"] as List<EnderecoViewModel>;
                if (lista == null)
                {
                    lista = new List<EnderecoViewModel>();
                    Session["EnderecosAluno"] = lista;
                }

                return lista;
            }
            set { Session["EnderecosAluno"] = value; }
        }
        private List<EnderecoViewModel> enderecosMae
        {
            get
            {
                var lista = Session["EnderecosMaeAluno"] as List<EnderecoViewModel>;
                if (lista == null)
                {
                    lista = new List<EnderecoViewModel>();
                    Session["EnderecosMaeAluno"] = lista;
                }

                return lista;
            }
            set { Session["EnderecosMaeAluno"] = value; }
        }
        private List<EnderecoViewModel> enderecosPai
        {
            get
            {
                var lista = Session["EnderecosPaiAluno"] as List<EnderecoViewModel>;
                if (lista == null)
                {
                    lista = new List<EnderecoViewModel>();
                    Session["EnderecosPaiAluno"] = lista;
                }

                return lista;
            }
            set { Session["EnderecosPaiAluno"] = value; }
        }
    }
}