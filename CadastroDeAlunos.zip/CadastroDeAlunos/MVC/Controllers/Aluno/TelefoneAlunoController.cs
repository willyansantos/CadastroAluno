﻿namespace MVC.Controllers.Aluno
{
    using global::AutoMapper;
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Entities.Enum;
    using ViewModel.Cadastro;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    public partial class AlunoController
    {
        public ActionResult AdicionarTelefone(TelefoneViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            if (telefones.Any(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Telefone já adicionado!", ETipoMensagem.INFORMATIVO) });

            var telefone = Mapper.Map<Telefone>(vm);
            if (!telefone.ValidarInserir()) return AlertErro(telefone.mensagens);

            vm.Action = "RemoverTelefone";
            vm.Controller = "Aluno";
            telefones.Add(vm);
            return Telefones();
        }
        public ActionResult RemoverTelefone(TelefoneViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            if (!telefones.Any(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Telefone não encontrado!", ETipoMensagem.INFORMATIVO) });

            telefones.Remove(telefones.FirstOrDefault(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero));
            return Telefones();
        }
        public ActionResult Telefone()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Aluno/_Telefone.cshtml", new TelefoneViewModel());
        }
        public ActionResult Telefones()
        {
            return PartialView("~/Views/Telefone/_Telefones.cshtml", telefones);
        }

        public ActionResult AdicionarTelefoneMae(TelefoneViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            if (telefonesMae.Any(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Telefone já adicionado!", ETipoMensagem.INFORMATIVO) });

            var telefone = Mapper.Map<Telefone>(vm);
            if (!telefone.ValidarInserir()) return AlertErro(telefone.mensagens);

            vm.Action = "RemoverTelefoneMae";
            vm.Controller = "Aluno";
            telefonesMae.Add(vm);
            return TelefonesMae();
        }
        public ActionResult RemoverTelefoneMae(TelefoneViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            if (!telefonesMae.Any(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Telefone não encontrado!", ETipoMensagem.INFORMATIVO) });

            telefonesMae.Remove(telefonesMae.FirstOrDefault(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero));
            return TelefonesMae();
        }
        public ActionResult TelefoneMae()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Aluno/Mae/_Telefone.cshtml", new TelefoneViewModel());
        }
        public ActionResult TelefonesMae()
        {
            return PartialView("~/Views/Telefone/_Telefones.cshtml", telefonesMae);
        }

        public ActionResult AdicionarTelefonePai(TelefoneViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            if (telefonesPai.Any(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Telefone já adicionado!", ETipoMensagem.INFORMATIVO) });

            var telefone = Mapper.Map<Telefone>(vm);
            if (!telefone.ValidarInserir()) return AlertErro(telefone.mensagens);

            vm.Action = "RemoverTelefonePai";
            vm.Controller = "Aluno";
            telefonesPai.Add(vm);
            return TelefonesPai();
        }
        public ActionResult RemoverTelefonePai(TelefoneViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            if (!telefonesPai.Any(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero))
                return AlertErro(new List<Mensagem> { new Mensagem("Telefone não encontrado!", ETipoMensagem.INFORMATIVO) });

            telefonesPai.Remove(telefonesPai.FirstOrDefault(c => c.Operadora == vm.Operadora && c.Numero == vm.Numero));
            return TelefonesPai();
        }
        public ActionResult TelefonePai()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return PartialView("~/Views/Aluno/Pai/_Telefone.cshtml", new TelefoneViewModel());
        }
        public ActionResult TelefonesPai()
        {
            return PartialView("~/Views/Telefone/_Telefones.cshtml", telefonesPai);
        }

        private List<TelefoneViewModel> telefones
        {
            get
            {
                var lista = Session["TelefonesAluno"] as List<TelefoneViewModel>;
                if (lista == null)
                {
                    lista = new List<TelefoneViewModel>();
                    Session["TelefonesAluno"] = lista;
                }

                return lista;
            }
            set { Session["TelefonesAluno"] = value; }
        }
        private List<TelefoneViewModel> telefonesMae
        {
            get
            {
                var lista = Session["TelefonesMaeAluno"] as List<TelefoneViewModel>;
                if (lista == null)
                {
                    lista = new List<TelefoneViewModel>();
                    Session["TelefonesMaeAluno"] = lista;
                }

                return lista;
            }
            set { Session["TelefonesMaeAluno"] = value; }
        }
        private List<TelefoneViewModel> telefonesPai
        {
            get
            {
                var lista = Session["TelefonesPaiAluno"] as List<TelefoneViewModel>;
                if (lista == null)
                {
                    lista = new List<TelefoneViewModel>();
                    Session["TelefonesPaiAluno"] = lista;
                }

                return lista;
            }
            set { Session["TelefonesPaiAluno"] = value; }
        }
    }
}