﻿namespace MVC.Controllers
{
    using Architecture;
    using System.Web.Mvc;

    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return View();
        }
    }
}