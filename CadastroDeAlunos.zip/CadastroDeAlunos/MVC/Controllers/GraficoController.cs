﻿namespace MVC.Controllers
{
    using Domain.Interfaces.Application.Cadastro;
    using Architecture;
    using ViewModel.Grafico;
    using System.Web.Mvc;
    using System.Linq;

    public class GraficoController : BaseController
    {
        private readonly IAlunoApplicationService alunoApplicationService;
        private readonly IMunicipioApplicationService municipioApplicationService;

        public GraficoController(IAlunoApplicationService alunoApplicationService, IMunicipioApplicationService municipioApplicationService)
        {
            this.alunoApplicationService = alunoApplicationService;
            this.municipioApplicationService = municipioApplicationService;
        }

        public ActionResult Index()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            var graficoViewModel = new GraficoViewModel
            {
                DadosAlunoPorDataHora = alunoApplicationService.ObterDadosParaGraficoPorDataHora(),
                DadosAlunoPorMunicipio = alunoApplicationService.ObterDadosParaGraficoPorMunicipio()
            };
            return View(graficoViewModel);
        }
    }
}