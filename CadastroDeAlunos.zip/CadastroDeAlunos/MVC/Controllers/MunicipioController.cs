﻿namespace MVC.Controllers
{
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Interfaces.Application.Cadastro;
    using global::AutoMapper;
    using Architecture;
    using ViewModel.Cadastro;
    using System.Web.Mvc;
    using System.Linq;

    public class MunicipioController : BaseController
    {
        private readonly IMunicipioApplicationService municipioApplicationService;

        public MunicipioController(IMunicipioApplicationService municipioApplicationService)
        {
            this.municipioApplicationService = municipioApplicationService;
        }

        public ActionResult Index()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return View();
        }

        public ActionResult Inserir()
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            return View();
        }

        [HttpPost]
        public ActionResult Inserir(MunicipioViewModel vm)
        {
            if (!UsuarioEstaLogado) return RedirectToAction("Login", "Autenticacao");

            municipioApplicationService.UsuarioLogado = UsuarioLogado;
            municipioApplicationService.Entidade = Mapper.Map<Municipio>(vm);
            municipioApplicationService.Inserir();
            EmitirMensagem(municipioApplicationService.ObterMensagens());

            if (municipioApplicationService.EstaValido) return RedirectToAction("Index");

            return View(vm);
        }

        public JsonResult ObterJQGrid(JQGrid jqGrid)
        {
            JQGridResult<MunicipioViewModel> result = Mapper.Map<JQGridResult<MunicipioViewModel>>(municipioApplicationService.ObterJQGrid(jqGrid));
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ObterMunicipiosPorUnidadeFederativa(int id)
        {
            return Json(municipioApplicationService.ObterMunicipiosPorUnidadeFederativa(id).AsEnumerable().Select(m => Mapper.Map<MunicipioViewModel>(m)), JsonRequestBehavior.AllowGet);
        }
    }
}