﻿namespace MVC.Controllers
{
    using Architecture;
    using ViewModel.Autenticacao;
    using System.Web.Mvc;
    using Domain.Entities.Autenticacao;
    using global::AutoMapper;
    using Domain.Interfaces.Application.Autenticacao;

    public class AutenticacaoController : BaseController
    {
        private IUsuarioApplicationService usuarioApplicationService;

        public AutenticacaoController(IUsuarioApplicationService usuarioApplicationService)
        {
            this.usuarioApplicationService = usuarioApplicationService;
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(UsuarioViewModel vm)
        {
            var usuario = usuarioApplicationService.ObterPorCpfSenha(vm.Cpf, vm.Senha);
            if (usuario != null)
            {
                Autenticar(Mapper.Map<UsuarioViewModel>(usuario));
                return RedirectToAction("Index", "Home");
            }

            return View();
        }

        public ActionResult Inserir()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Inserir(UsuarioViewModel vm)
        {
            usuarioApplicationService.UsuarioLogado = UsuarioLogado;
            usuarioApplicationService.Entidade = Mapper.Map<Usuario>(vm);
            usuarioApplicationService.Inserir();
            EmitirMensagem(usuarioApplicationService.ObterMensagens());

            if (usuarioApplicationService.EstaValido) return RedirectToAction("Login");

            return View(vm);
        }

        public ActionResult Sair()
        {
            Desautenticar();
            return RedirectToAction("Login");
        }
    }
}