﻿namespace MVC.Architecture
{
    using System.Web.Mvc;

    public class ErrorResult : ContentResult
    {
        private readonly string _erro;

        public ErrorResult(string erro)
        {
            _erro = erro;
        }

        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.StatusCode = 500;
            context.HttpContext.Response.TrySkipIisCustomErrors = true;
            context.HttpContext.Response.Write(_erro);
        }
    }
}