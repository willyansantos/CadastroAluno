﻿namespace MVC.Architecture
{
    using Domain.Entities;
    using ViewModel.Autenticacao;
    using System.Collections.Generic;
    using System.Web.Mvc;
    using System.Linq;

    public class BaseController : Controller
    {
        protected UsuarioLogado UsuarioLogado { get { return Session?["UsuarioLogado"] as UsuarioLogado; } }
        protected bool UsuarioEstaLogado => UsuarioLogado != null;
        private string layout_mensagem => "<br/><span class='label {0}'>{1}</span>";
        public BaseController()
        {
        }

        public void Autenticar(UsuarioViewModel usuario)
        {
            if (!UsuarioEstaLogado)
            {
                var UsuarioLogado = new UsuarioLogado { UsuarioID = usuario.UsuarioID, Cpf = usuario.Cpf, Nome = usuario.Nome, Email = usuario.Email };
                Session["UsuarioLogado"] = UsuarioLogado;
            }
        }

        public void Desautenticar()
        {
            Session["UsuarioLogado"] = null;
        }

        public void EmitirMensagem(List<Mensagem> mensagens)
        {
            List<string> lista = new List<string>();
            foreach (var mensagem in mensagens)
            {
                switch (mensagem.Tipo)
                {
                    case Domain.Entities.Enum.ETipoMensagem.INFORMATIVO:
                        lista.Add(string.Format(layout_mensagem, "label-info", mensagem.Texto));
                        break;
                    case Domain.Entities.Enum.ETipoMensagem.SUCESSO:
                        lista.Add(string.Format(layout_mensagem, "label-success", mensagem.Texto));
                        break;
                    case Domain.Entities.Enum.ETipoMensagem.AVISO:
                        lista.Add(string.Format(layout_mensagem, "label-warning", mensagem.Texto));
                        break;
                    case Domain.Entities.Enum.ETipoMensagem.ERRO:
                    case Domain.Entities.Enum.ETipoMensagem.ERRO_DE_VALIDAÇÃO:
                        lista.Add(string.Format(layout_mensagem, "label-danger", mensagem.Texto));
                        break;
                }
            }
            TempData["ListaMensagens"] = lista;
        }

        protected ErrorResult AlertErro(List<Mensagem> mensagens)
        {
            return new ErrorResult(string.Join("<br/>", mensagens.Select(m => m.Texto)));
        }
    }
}