﻿namespace Domain.Interfaces.Services
{
    using System;
    using System.Linq;
    using System.Linq.Expressions;

    public interface IServiceBase<E> where E : class
    {
        bool Inserir(E entity);
        E Obter(Expression<Func<E, bool>> where);
        IQueryable<E> ObterTodos();
        IQueryable<E> ObterTodosPaginando(string order, string typeorder, int startRowIndex, int maximumRows);
        IQueryable<E> ObterSomente(Expression<Func<E, bool>> where);
        IQueryable<E> ObterSomentePaginando(Expression<Func<E, bool>> where, string order, string typeorder, int startRowIndex, int maximumRows);
        int ContarSomente(Expression<Func<E, bool>> where);
        void Dispose();
    }
}
