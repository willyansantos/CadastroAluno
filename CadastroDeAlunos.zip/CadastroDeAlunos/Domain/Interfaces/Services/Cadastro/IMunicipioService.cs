﻿namespace Domain.Interfaces.Services.Cadastro
{
    using System.Linq;
    using Domain.Entities;
    using Domain.Entities.Cadastro;

    public interface IMunicipioService : IServiceBase<Municipio>
    {
        Municipio Obter(int id);
        JQGridResult<Municipio> ObterJQGrid(JQGrid jqGrid);
        IQueryable<Municipio> ObterMunicipiosPorUnidadeFederativa(int id);
    }
}
