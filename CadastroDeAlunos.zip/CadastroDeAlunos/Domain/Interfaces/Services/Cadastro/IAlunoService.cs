﻿namespace Domain.Interfaces.Services.Cadastro
{
    using System.Linq;
    using Entities;
    using Entities.Cadastro;
    using System.Collections.Generic;

    public interface IAlunoService : IServiceBase<Aluno>
    {
        JQGridResult<Aluno> ObterJQGrid(JQGrid jqGrid);
        JQGridResult<Aluno> ObterJQGridPorMunicipio(int id, JQGrid jqGrid);
        IEnumerable<IGrouping<string, Aluno>> ObterDadosParaGraficoPorDataHora();
        List<KeyValuePair<string, List<Aluno>>> ObterDadosParaGraficoPorMunicipio();
    }
}
