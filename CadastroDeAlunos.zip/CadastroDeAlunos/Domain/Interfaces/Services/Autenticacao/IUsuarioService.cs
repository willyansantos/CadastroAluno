﻿namespace Domain.Interfaces.Services.Autenticacao
{
    using Entities.Autenticacao;

    public interface IUsuarioService : IServiceBase<Usuario>
    {
        Usuario ObterPorCpfSenha(string cpf, string senha);
    }
}
