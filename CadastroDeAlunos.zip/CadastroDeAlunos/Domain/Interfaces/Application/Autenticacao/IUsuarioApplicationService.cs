﻿namespace Domain.Interfaces.Application.Autenticacao
{
    using Domain.Entities.Autenticacao;
    using Domain.Interfaces.Application.Architecture;

    public interface IUsuarioApplicationService : IApplicationServiceBase<Usuario>
    {
        Usuario ObterPorCpfSenha(string cpf, string senha);
        void Inserir();
    }
}
