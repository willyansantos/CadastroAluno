﻿namespace Domain.Interfaces.Application.Architecture
{
    using Entities;
    using System.Collections.Generic;

    public interface IApplicationServiceBase<E> where E : class
    {
        E Entidade { get; set; }
        UsuarioLogado UsuarioLogado { get; set; }
        bool EstaValido { get; set; }
        List<Mensagem> ObterMensagens();
    }
}
