﻿namespace Domain.Interfaces.Application.Cadastro
{
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Interfaces.Application.Architecture;
    using System.Linq;

    public interface IMunicipioApplicationService : IApplicationServiceBase<Municipio>
    {
        JQGridResult<Municipio> ObterJQGrid(JQGrid jqGrid);
        void Inserir();
        IQueryable<Municipio> ObterMunicipiosPorUnidadeFederativa(int id);
        Municipio Obter(int id);
    }
}
