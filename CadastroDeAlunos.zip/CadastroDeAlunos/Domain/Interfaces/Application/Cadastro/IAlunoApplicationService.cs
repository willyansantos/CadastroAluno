﻿namespace Domain.Interfaces.Application.Cadastro
{
    using System.Linq;
    using Domain.Interfaces.Application.Architecture;
    using Entities;
    using Entities.Cadastro;
    using System.Collections.Generic;

    public interface IAlunoApplicationService : IApplicationServiceBase<Aluno>
    {
        JQGridResult<Aluno> ObterJQGrid(JQGrid jqGrid);
        JQGridResult<Aluno> ObterJQGridPorMunicipio(int id, JQGrid jqGrid);
        void Inserir();
        IEnumerable<IGrouping<string, Aluno>> ObterDadosParaGraficoPorDataHora();
        List<KeyValuePair<string, List<Aluno>>> ObterDadosParaGraficoPorMunicipio();
    }
}
