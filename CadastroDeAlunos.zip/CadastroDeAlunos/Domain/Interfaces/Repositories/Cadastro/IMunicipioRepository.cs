﻿namespace Domain.Interfaces.Repositories.Cadastro
{
    using Domain.Entities.Cadastro;

    public interface IMunicipioRepository : IRepositoryGeneric<Municipio>
    {
    }
}
