﻿namespace Domain.Interfaces.Repositories.Cadastro
{
    using Domain.Entities.Cadastro;

    public interface IAlunoRepository : IRepositoryGeneric<Aluno>
    {
    }
}
