﻿namespace Domain.Interfaces.Repositories.Autenticacao
{
    using Entities.Autenticacao;

    public interface IUsuarioRepository : IRepositoryGeneric<Usuario>
    {
    }
}
