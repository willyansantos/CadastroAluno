﻿namespace Domain.Util
{
    using System;
    using System.ComponentModel;
    using System.Reflection;
    using System.Text.RegularExpressions;

    public static class Extensao
    {
        public static string RemoveMascara(this string texto)
        {
            return string.IsNullOrEmpty(texto) ? null : Regex.Replace(texto, "[?\\)?\\(_./-]", "").Trim();
        }

        public static string FormatarCep(this string str)
        {
            if (str == null) return string.Empty;

            if (str.Length != 8) return str;

            return $"{str.Substring(0, 2)}.{str.Substring(2, 3)}-{str.Substring(5)}";
        }

        public static string FormatarTelefone(this string str)
        {
            if (str == null) return string.Empty;

            if (str.Length != 11) return str;

            return $"({str.Substring(0, 3)}) {str.Substring(3, 4)}-{str.Substring(7)}";
        }

        public static string FormatarCPF(this string cpf)
        {
            if (string.IsNullOrEmpty(cpf)) return string.Empty;

            if (cpf.Length != 11) return cpf;

            return $"{cpf.Substring(0, 3)}.{cpf.Substring(3, 3)}.{cpf.Substring(6, 3)}-{cpf.Substring(9, 2)}";
        }

        public static string Descricao(this Enum el)
        {
            if (el == null) return string.Empty;

            FieldInfo infoElemento = el.GetType().GetField(el.ToString());
            if (infoElemento == null) return string.Empty;

            DescriptionAttribute[] atributos = (DescriptionAttribute[])infoElemento.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (atributos.Length > 0 && atributos[0].Description != null) return atributos[0].Description.FormatarNomeEnum();

            return el.ToString().FormatarNomeEnum();
        }
    }
}
