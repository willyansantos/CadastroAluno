﻿namespace Domain.Services
{
    using Domain.Interfaces.Repositories;
    using Domain.Interfaces.Services;
    using System;
    using System.Linq;
    using System.Linq.Expressions;

    public class ServiceBase<E> : IDisposable, IServiceBase<E> where E : class
    {
        private readonly IRepositoryGeneric<E> repository;

        public ServiceBase(IRepositoryGeneric<E> repository)
        {
            this.repository = repository;
        }

        public int ContarSomente(Expression<Func<E, bool>> where)
        {
            return repository.ContarSomente(where);
        }

        public void Dispose()
        {
            repository.Dispose();
        }

        public bool Inserir(E entity)
        {
            return repository.Inserir(entity);
        }

        public E Obter(Expression<Func<E, bool>> where)
        {
            return repository.Obter(where);
        }

        public IQueryable<E> ObterSomente(Expression<Func<E, bool>> where)
        {
            return repository.ObterSomente(where);
        }

        public IQueryable<E> ObterSomentePaginando(Expression<Func<E, bool>> where, string order, string typeorder, int startRowIndex, int maximumRows)
        {
            return repository.ObterSomentePaginando(where, order, typeorder, startRowIndex, maximumRows);
        }

        public IQueryable<E> ObterTodos()
        {
            return repository.ObterTodos();
        }

        public IQueryable<E> ObterTodosPaginando(string order, string typeorder, int startRowIndex, int maximumRows)
        {
            return repository.ObterTodosPaginando(order, typeorder, startRowIndex, maximumRows);
        }
    }
}
