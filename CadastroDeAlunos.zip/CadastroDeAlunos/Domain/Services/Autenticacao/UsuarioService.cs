﻿namespace Domain.Services.Autenticacao
{
    using Interfaces.Repositories.Autenticacao;
    using Interfaces.Services.Autenticacao;
    using Entities.Autenticacao;

    public class UsuarioService : ServiceBase<Usuario>, IUsuarioService
    {
        private readonly IUsuarioRepository usuarioRepository;

        public UsuarioService(IUsuarioRepository usuarioRepository) : base(usuarioRepository)
        {
            this.usuarioRepository = usuarioRepository;
        }

        public Usuario ObterPorCpfSenha(string cpf, string senha)
        {
            return usuarioRepository.Obter(u => u.Pessoa.Cpf == cpf && u.Senha == senha);
        }
    }
}
