﻿namespace Domain.Services.Cadastro
{
    using Domain.Entities.Cadastro;
    using Domain.Interfaces.Repositories.Cadastro;
    using Domain.Interfaces.Services.Cadastro;
    using Domain.Entities;
    using System.Linq;
    using System.Collections.Generic;

    public class AlunoService : ServiceBase<Aluno>, IAlunoService
    {
        public AlunoService(IAlunoRepository alunoRepository) : base(alunoRepository) { }

        public IEnumerable<IGrouping<string, Aluno>> ObterDadosParaGraficoPorDataHora()
        {
            return ObterTodos().AsEnumerable().GroupBy(a => a.DataCadastro.ToString("dd/MM/yyy HH"));
        }

        public List<KeyValuePair<string, List<Aluno>>> ObterDadosParaGraficoPorMunicipio()
        {
            List<KeyValuePair<string, List<Aluno>>> lista = new List<KeyValuePair<string, List<Aluno>>>();
            foreach (var item in ObterSomente(a => a.Pessoa.Enderecos.Any()).AsEnumerable().GroupBy(a => a.Pessoa.Enderecos.GroupBy(e => e.Municipio.Nome)))
            {
                foreach (var agrupadorPorMunicipio in item.Key)
                {
                    if (lista.Any(x => x.Key == agrupadorPorMunicipio.Key))
                    {
                        var chave = lista.FirstOrDefault(x => x.Key == agrupadorPorMunicipio.Key);
                        chave.Value.AddRange(item.ToList());
                    }
                    else
                        lista.Add(new KeyValuePair<string, List<Aluno>>(agrupadorPorMunicipio.Key, item.ToList()));
                }
            }
            return lista;
        }

        public JQGridResult<Aluno> ObterJQGrid(JQGrid jqGrid)
        {
            JQGridResult<Aluno> jQGridResult = new JQGridResult<Aluno>(jqGrid);
            jQGridResult.records = ObterTodos().Count();
            jQGridResult.rows = ObterTodosPaginando(jqGrid.sidx, jqGrid.sord, jqGrid.starRowIndex, jqGrid.rows);
            return jQGridResult;
        }

        public JQGridResult<Aluno> ObterJQGridPorMunicipio(int id, JQGrid jqGrid)
        {
            JQGridResult<Aluno> jQGridResult = new JQGridResult<Aluno>(jqGrid);
            jQGridResult.records = ObterSomente(x => x.Pessoa.Enderecos.Any(e => e.MunicipioID == id)).Count();
            jQGridResult.rows = ObterSomentePaginando(x => x.Pessoa.Enderecos.Any(e => e.MunicipioID == id), jqGrid.sidx, jqGrid.sord, jqGrid.starRowIndex, jqGrid.rows);
            return jQGridResult;
        }
    }
}
