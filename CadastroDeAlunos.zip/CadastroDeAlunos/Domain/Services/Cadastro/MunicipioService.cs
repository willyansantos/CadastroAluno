﻿namespace Domain.Interfaces.Services.Cadastro
{
    using Domain.Entities;
    using Domain.Entities.Cadastro;
    using Domain.Interfaces.Repositories.Cadastro;
    using Domain.Services;
    using System.Linq;

    public class MunicipioService : ServiceBase<Municipio>, IMunicipioService
    {
        public MunicipioService(IMunicipioRepository municipioRepository) : base(municipioRepository) { }

        public Municipio Obter(int id)
        {
            return Obter(m => m.MunicipioID == id);
        }

        public JQGridResult<Municipio> ObterJQGrid(JQGrid jqGrid)
        {
            JQGridResult<Municipio> jQGridResult = new JQGridResult<Municipio>(jqGrid);
            jQGridResult.records = ObterTodos().Count();
            jQGridResult.rows = ObterTodosPaginando(jqGrid.sidx, jqGrid.sord, jqGrid.starRowIndex, jqGrid.rows);
            return jQGridResult;
        }

        public IQueryable<Municipio> ObterMunicipiosPorUnidadeFederativa(int id)
        {
            return ObterSomente(m => m.UnidadeFederativaID == id);
        }
    }
}
