﻿namespace Domain.Entities
{
    using Newtonsoft.Json;
    using System.Collections.Generic;

    public class EntityBase
    {
        [JsonIgnore, JsonProperty(Required = Required.Default)]
        public List<Mensagem> mensagens;

        public EntityBase()
        {
            mensagens = new List<Mensagem>();
        }
    }
}
