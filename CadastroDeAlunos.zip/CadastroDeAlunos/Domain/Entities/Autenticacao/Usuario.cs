﻿namespace Domain.Entities.Autenticacao
{
    using Cadastro;
    using Enum;
    using System;

    public partial class Usuario : EntityBase
    {
        public int UsuarioID { get; set; }
        public int PessoaID { get; set; }
        public string Senha { get; set; }
        public DateTime DataCadastro { get; set; }

        public virtual Pessoa Pessoa { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (string.IsNullOrWhiteSpace(Senha))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar a senha!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            Pessoa = Pessoa ?? new Pessoa();
            var valido = Pessoa.ValidarInserir(false, false);
            estaValido = estaValido ? valido : estaValido;
            mensagens.AddRange(Pessoa.mensagens);

            return estaValido;
        }
    }
}
