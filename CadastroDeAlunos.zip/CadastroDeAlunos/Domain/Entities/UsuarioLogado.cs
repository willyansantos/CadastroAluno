﻿namespace Domain.Entities
{
    using System;

    [Serializable]
    public class UsuarioLogado
    {
        public int UsuarioID { get; set; }
        public string Cpf { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
    }
}