﻿namespace Domain.Entities.Cadastro
{
    using Domain.Entities.Enum;
    using Domain.Util;
    using Entities.Autenticacao;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using static System.DateTime;

    public partial class Pessoa : EntityBase
    {
        public Pessoa()
        {
            Enderecos = new List<Endereco>();
            Telefones = new List<Telefone>();
        }

        public int PessoaID { get; set; }
        public string Nome { get; set; }
        public string Rg { get; set; }
        public string Cpf { get; set; }
        public string Email { get; set; }
        public DateTime DataNascimento { get; set; }
        public int TipoSexo { get; set; }
        public string Profissao { get; set; }
        public DateTime DataCadastro { get; set; }
        public int? UsuarioCadastroID { get; set; }
        public DateTime? DataAtualizacao { get; set; }
        public int? UsuarioAtualizacaoID { get; set; }

        public virtual ICollection<Endereco> Enderecos { get; set; }
        public virtual Valor ValorTipoSexo { get; set; }
        public virtual Usuario UsuarioAtualizacao { get; set; }
        public virtual Usuario UsuarioCadastro { get; set; }
        public virtual ICollection<Telefone> Telefones { get; set; }

        public bool ValidarInserir(bool comTelefone = true, bool comEndereco = true)
        {
            bool estaValido = true;

            if (string.IsNullOrWhiteSpace(Cpf))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o cpf!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }
            else
            {
                Cpf = Cpf.RemoveMascara();
                if (!Cpf.ValidarCPF())
                {
                    estaValido = false;
                    mensagens.Add(new Mensagem("Cpf invalido!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
                }
            }

            if (string.IsNullOrWhiteSpace(Nome))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o nome!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (string.IsNullOrWhiteSpace(Rg))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o rg!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (!string.IsNullOrWhiteSpace(Email) && !Email.ValidaEmail())
            {
                estaValido = false;
                mensagens.Add(new Mensagem("O e-mail esta invalido!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (DataNascimento == null || DataNascimento == MinValue)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar a data de nascimento!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }
            else if (DataNascimento > Today)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("A data de nascimento nao pode ser maior que hoje!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (TipoSexo == 0)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o sexo!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (comEndereco)
            {
                if (Enderecos.Any())
                {
                    foreach (var endereco in Enderecos)
                    {
                        var valido = endereco.ValidarInserir();
                        mensagens.AddRange(endereco.mensagens);
                        estaValido = estaValido ? valido : estaValido;
                    }
                }
                else
                {
                    estaValido = false;
                    mensagens.Add(new Mensagem("Obrigatorio informar ao menos um endereco!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
                }
            }

            if (comTelefone)
            {
                if (Telefones.Any())
                {
                    foreach (var telefone in Telefones)
                    {
                        var valido = telefone.ValidarInserir();
                        mensagens.AddRange(telefone.mensagens);
                        estaValido = estaValido ? valido : estaValido;
                    }
                }
                else
                {
                    estaValido = false;
                    mensagens.Add(new Mensagem("Obrigatorio informar ao menos um telefone!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
                }
            }

            return estaValido;
        }
    }
}
