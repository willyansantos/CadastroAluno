﻿namespace Domain.Entities.Cadastro
{
    using Autenticacao;
    using System;

    //[JsonObject(ItemRequired = Required.Always)]
    public partial class Aluno : EntityBase
    {
        public int PessoaID { get; set; }
        public string Matricula { get; set; }
        public int? PaiPessoaID { get; set; }
        public int? MaePessoaID { get; set; }
        public DateTime DataCadastro { get; set; }
        public int UsuarioCadastroID { get; set; }
        public DateTime? DataAtualizacao { get; set; }
        public int? UsuarioAtualizacaoID { get; set; }

        public virtual Pessoa Pessoa { get; set; }
        public virtual Pessoa Pai { get; set; }
        public virtual Pessoa Mae { get; set; }
        //[JsonIgnore, JsonProperty(Required = Required.Default)]
        public virtual Usuario UsuarioAtualizacao { get; set; }
        public virtual Usuario UsuarioCadastro { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (string.IsNullOrWhiteSpace(Matricula))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar a matricula!", Entities.Enum.ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            Pessoa = Pessoa ?? new Pessoa();
            var valido = Pessoa.ValidarInserir();
            estaValido = estaValido ? valido : estaValido;
            mensagens.AddRange(Pessoa.mensagens);

            if (Mae != null)
            {
                valido = Mae.ValidarInserir(true, false);
                estaValido = estaValido ? valido : estaValido;
                mensagens.AddRange(Mae.mensagens);
            }

            if (Pai != null)
            {
                valido = Pai.ValidarInserir(true, false);
                estaValido = estaValido ? valido : estaValido;
                mensagens.AddRange(Pai.mensagens);
            }

            return estaValido;
        }
    }
}
