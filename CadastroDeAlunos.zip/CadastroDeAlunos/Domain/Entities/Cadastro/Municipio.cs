﻿namespace Domain.Entities.Cadastro
{
    using Domain.Entities.Enum;
    using System;
    using Domain.Entities.Autenticacao;

    public partial class Municipio : EntityBase
    {
        public int MunicipioID { get; set; }
        public string Nome { get; set; }
        public int UnidadeFederativaID { get; set; }
        public DateTime DataCadastro { get; set; }
        public int? UsuarioCadastroID { get; set; }
        public DateTime? DataAtualizacao { get; set; }
        public int? UsuarioAtualizacaoID { get; set; }

        public virtual UnidadeFederativa UnidadeFederativa { get; set; }
        public virtual Usuario UsuarioAtualizacao { get; set; }
        public virtual Usuario UsuarioCadastro { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (string.IsNullOrWhiteSpace(Nome))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o nome!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (UnidadeFederativaID == 0)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o estado!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            return estaValido;
        }
    }
}
