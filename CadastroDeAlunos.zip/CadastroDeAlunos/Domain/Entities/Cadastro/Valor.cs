﻿namespace Domain.Entities.Cadastro
{
    using Enum;

    public partial class Valor : EntityBase
    {
        public int ValorID { get; set; }
        public string Nome { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (string.IsNullOrWhiteSpace(Nome))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o nome!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            return estaValido;
        }
    }
}
