﻿namespace Domain.Entities.Cadastro
{
    using Domain.Entities.Enum;
    using Domain.Util;

    public partial class Endereco : EntityBase
    {
        public int EnderecoID { get; set; }
        public int PessoaID { get; set; }
        public string Logradouro { get; set; }
        public string Numero { get; set; }
        public string Cep { get; set; }
        public string Bairro { get; set; }
        public int MunicipioID { get; set; }
        public string Complemento { get; set; }

        public virtual Municipio Municipio { get; set; }
        public virtual Pessoa Pessoa { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (string.IsNullOrWhiteSpace(Logradouro))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o logradouro!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (string.IsNullOrWhiteSpace(Numero))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o numero!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            Cep = Cep.RemoveMascara();
            if (string.IsNullOrWhiteSpace(Cep))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o cep!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (string.IsNullOrWhiteSpace(Bairro))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o bairro!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (MunicipioID == 0)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o municipio!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            return estaValido;
        }
    }
}
