﻿namespace Domain.Entities.Cadastro
{
    using Enum;

    public partial class UnidadeFederativa : EntityBase
    {
        public int UnidadeFederativaID { get; set; }
        public string Nome { get; set; }
        public string UF { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (UnidadeFederativaID == 0)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o numero!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (string.IsNullOrWhiteSpace(Nome))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o nome!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (string.IsNullOrWhiteSpace(UF))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar a uf!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            return estaValido;
        }
    }
}
