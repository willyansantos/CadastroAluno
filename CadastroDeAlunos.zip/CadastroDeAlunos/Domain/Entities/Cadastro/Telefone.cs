﻿namespace Domain.Entities.Cadastro
{
    using Domain.Entities.Enum;
    using Domain.Util;

    public partial class Telefone : EntityBase
    {
        public int TelefoneID { get; set; }
        public int PessoaID { get; set; }
        public int TipoTelefone { get; set; }
        public string DDD { get; set; }
        public string Numero { get; set; }
        public int Operadora { get; set; }
        public string Contato { get; set; }

        public virtual Pessoa Pessoa { get; set; }
        public virtual Valor ValorOperadora { get; set; }
        public virtual Valor ValorTipoTelefone { get; set; }

        public bool ValidarInserir()
        {
            bool estaValido = true;

            if (TipoTelefone == 0)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o tipo!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (string.IsNullOrEmpty(DDD))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o ddd!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            Numero = Numero.RemoveMascara();
            if (string.IsNullOrEmpty(Numero))
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar o numero!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            if (Operadora == 0)
            {
                estaValido = false;
                mensagens.Add(new Mensagem("Obrigatorio informar a operadora!", ETipoMensagem.ERRO_DE_VALIDAÇÃO));
            }

            return estaValido;
        }
    }
}
