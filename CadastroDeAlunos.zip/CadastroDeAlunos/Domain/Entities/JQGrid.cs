﻿namespace Domain.Entities
{
    public class JQGrid
    {
        public int rows { get; set; }
        public int page { get; set; }
        public string sidx { get; set; }
        public string sord { get; set; }

        public int starRowIndex => (page > 0) ? (page - 1) * rows : 0;
    }
}
