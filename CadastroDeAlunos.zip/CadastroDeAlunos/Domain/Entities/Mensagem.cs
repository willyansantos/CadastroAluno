﻿namespace Domain.Entities
{
    using Enum;

    public class Mensagem
    {
        public Mensagem(string mensagem, ETipoMensagem tipo)
        {
            Texto = mensagem;
            Tipo = tipo;
        }

        public string Texto { get; set; }
        public ETipoMensagem Tipo { get; set; }
    }
}
