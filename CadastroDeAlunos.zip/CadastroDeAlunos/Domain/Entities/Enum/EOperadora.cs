﻿namespace Domain.Entities.Enum
{
    public enum EOperadora
    {
        Claro = 8,
        Vivo = 9,
        Oi = 10,
        Tim = 11
    }
}
