﻿namespace Domain.Entities.Enum
{
    public enum EUnidadeFederativa
    {
        RS = 1,
        SC = 2,
        PR = 3,
        SP = 4,
        MG = 5,
        RJ = 6,
        ES = 7,
        MS = 8,
        MT = 9,
        GO = 10,
        TO = 11,
        PA = 12,
        AM = 13,
        RO = 14,
        RR = 15,
        AC = 16,
        DF = 17,
        BA = 18,
        SE = 19,
        CE = 20,
        PI = 21,
        PB = 22,
        RN = 23,
        AL = 24,
        MA = 25,
        PE = 26,
        AP = 27
    }
}
