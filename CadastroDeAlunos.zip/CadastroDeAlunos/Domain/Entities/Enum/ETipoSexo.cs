﻿namespace Domain.Entities.Enum
{
    public enum ETipoSexo
    {
        Feminino = 1,
        Masculino = 2
    }
}
