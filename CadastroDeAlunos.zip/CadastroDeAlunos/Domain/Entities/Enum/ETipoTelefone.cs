﻿namespace Domain.Entities.Enum
{
    public enum ETipoTelefone
    {
        Comercial = 3,
        Residencial = 4,
        Celular = 5,
        Recado = 6,
        Fax = 7
    }
}
