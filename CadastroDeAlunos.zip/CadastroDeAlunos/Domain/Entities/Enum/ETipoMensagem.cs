﻿namespace Domain.Entities.Enum
{
    public enum ETipoMensagem
    {
        INFORMATIVO,
        SUCESSO,
        AVISO,
        ERRO,
        ERRO_DE_VALIDAÇÃO
    }
}
