﻿namespace Domain.Entities
{
    using System;
    using System.Collections.Generic;

    [Serializable]
    public class JQGridResult<E>
    {
        public JQGridResult() { }
        public JQGridResult(JQGrid jqGrid)
        {
            qtdReg = jqGrid.rows;
            page = jqGrid.page;
        }

        public int qtdReg { get; set; }
        public long records { get; set; }
        public int page { get; set; }
        public int total { get { return (int)Math.Ceiling((decimal)records / qtdReg); } }
        public IEnumerable<E> rows { get; set; }
    }
}
