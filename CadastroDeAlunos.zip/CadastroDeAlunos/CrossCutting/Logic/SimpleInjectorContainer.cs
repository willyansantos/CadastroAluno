﻿namespace CrossCutting.Logic
{
    using Application.Logic.Autenticacao;
    using Application.Logic.Cadastro;
    using Domain.Interfaces.Application.Autenticacao;
    using Domain.Interfaces.Application.Cadastro;
    using Domain.Interfaces.Repositories.Autenticacao;
    using Domain.Interfaces.Repositories.Cadastro;
    using Domain.Interfaces.Services.Autenticacao;
    using Domain.Interfaces.Services.Cadastro;
    using Domain.Services.Autenticacao;
    using Domain.Services.Cadastro;
    using Infra.Logic.Autenticacao;
    using Infra.Logic.Cadastro;
    using SimpleInjector;

    public class SimpleInjectorContainer
    {
        public static void RegisterServices(Container container)
        {
            //Repository
            container.Register<IUsuarioRepository, UsuarioRepository>(Lifestyle.Scoped);
            container.Register<IAlunoRepository, AlunoRepository>(Lifestyle.Scoped);
            container.Register<IMunicipioRepository, MunicipioRepository>(Lifestyle.Scoped);

            //Service
            container.Register<IUsuarioService, UsuarioService>(Lifestyle.Scoped);
            container.Register<IAlunoService, AlunoService>(Lifestyle.Scoped);
            container.Register<IMunicipioService, MunicipioService>(Lifestyle.Scoped);

            //Application
            container.Register<IUsuarioApplicationService, UsuarioApplicationService>(Lifestyle.Scoped);
            container.Register<IAlunoApplicationService, AlunoApplicationService>(Lifestyle.Scoped);
            container.Register<IMunicipioApplicationService, MunicipioApplicationService>(Lifestyle.Scoped);
        }
    }
}
