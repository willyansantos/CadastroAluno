﻿namespace Application.Architecture
{
    using Domain.Entities;
    using Domain.Entities.Enum;
    using Domain.Interfaces.Application.Architecture;
    using System.Collections.Generic;

    public abstract class ApplicationServiceBase<E> : IApplicationServiceBase<E> where E : class, new()
    {
        public E Entidade { get; set; }
        public bool EstaValido { get; set; }
        public UsuarioLogado UsuarioLogado { get; set; }
        private readonly List<Mensagem> mensagensBusiness;

        protected ApplicationServiceBase()
        {
            EstaValido = true;
            mensagensBusiness = new List<Mensagem>();
            UsuarioLogado = new UsuarioLogado();
        }

        protected void AdicionarMensagem(Mensagem mensagem)
        {
            mensagensBusiness.Add(mensagem);
        }

        protected void LimparMensagem()
        {
            mensagensBusiness.Clear();
        }

        protected void LimparMensagem(ETipoMensagem tipoMensagem)
        {
            mensagensBusiness.RemoveAll(m => m.Tipo == tipoMensagem);
        }

        protected void AdicionarMensagem(string mensagem, ETipoMensagem mensagemTipo)
        {
            if (mensagemTipo == ETipoMensagem.ERRO)
                mensagem = "Não foi possível realizar a operação! " + mensagem;

            mensagensBusiness.Add(new Mensagem(mensagem, mensagemTipo));
        }

        protected void AdicionarMensagens(List<Mensagem> mensagens)
        {
            mensagensBusiness.AddRange(mensagens);
        }

        public List<Mensagem> ObterMensagens()
        {
            return mensagensBusiness;
        }
    }
}
