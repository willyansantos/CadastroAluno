﻿namespace Application.Logic.Cadastro
{
    using Architecture;
    using Domain.Entities.Enum;
    using Domain.Entities.Cadastro;
    using Domain.Entities;
    using Domain.Interfaces.Services.Cadastro;
    using Domain.Interfaces.Application.Cadastro;
    using static System.DateTime;
    using System.Linq;

    public class MunicipioApplicationService : ApplicationServiceBase<Municipio>, IMunicipioApplicationService
    {
        private readonly IMunicipioService municipioService;

        public MunicipioApplicationService(IMunicipioService municipioService)
        {
            this.municipioService = municipioService;
        }

        public JQGridResult<Municipio> ObterJQGrid(JQGrid jqGrid)
        {
            return municipioService.ObterJQGrid(jqGrid);
        }

        public void Inserir()
        {
            EstaValido = Entidade.ValidarInserir();

            if (!EstaValido)
            {
                AdicionarMensagens(Entidade.mensagens);
                return;
            }

            Entidade.UsuarioCadastroID = UsuarioLogado.UsuarioID;
            Entidade.DataCadastro = Now;
            EstaValido = municipioService.Inserir(Entidade);

            if (EstaValido)
                AdicionarMensagem("Municipio cadastrado com sucesso!", ETipoMensagem.SUCESSO);
            else
                AdicionarMensagem("Nao foi possivel cadastrar o municipio!", ETipoMensagem.ERRO);
        }

        public IQueryable<Municipio> ObterMunicipiosPorUnidadeFederativa(int id)
        {
            return municipioService.ObterMunicipiosPorUnidadeFederativa(id);
        }

        public Municipio Obter(int id)
        {
            return municipioService.Obter(id);
        }
    }
}
