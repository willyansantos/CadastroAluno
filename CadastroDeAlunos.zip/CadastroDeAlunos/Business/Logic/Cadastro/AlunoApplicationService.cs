﻿namespace Application.Logic.Cadastro
{
    using Architecture;
    using Domain.Entities.Cadastro;
    using Domain.Entities;
    using Domain.Interfaces.Services.Cadastro;
    using Domain.Interfaces.Application.Cadastro;
    using static System.DateTime;
    using Domain.Entities.Enum;
    using System.Linq;
    using System.Collections.Generic;

    public class AlunoApplicationService : ApplicationServiceBase<Aluno>, IAlunoApplicationService
    {
        private readonly IAlunoService alunoService;

        public AlunoApplicationService(IAlunoService alunoService)
        {
            this.alunoService = alunoService;
        }

        public void Inserir()
        {
            EstaValido = Entidade.ValidarInserir();

            if (!EstaValido)
            {
                AdicionarMensagens(Entidade.mensagens);
                return;
            }

            Entidade.DataCadastro = Now;
            Entidade.Pessoa.DataCadastro = Entidade.DataCadastro;
            Entidade.Pessoa.UsuarioCadastroID = UsuarioLogado.UsuarioID;
            if (Entidade.Pai != null)
            {
                Entidade.Pai.DataCadastro = Entidade.DataCadastro;
                Entidade.Pai.UsuarioCadastroID = UsuarioLogado.UsuarioID;
            }

            if (Entidade.Mae != null)
            {
                Entidade.Mae.DataCadastro = Entidade.DataCadastro;
                Entidade.Mae.UsuarioCadastroID = UsuarioLogado.UsuarioID;
            }

            Entidade.UsuarioCadastroID = UsuarioLogado.UsuarioID;
            EstaValido = alunoService.Inserir(Entidade);

            if (EstaValido)
                AdicionarMensagem("Aluno cadastrado com sucesso!", ETipoMensagem.SUCESSO);
            else
                AdicionarMensagem("Nao foi possivel cadastrar o aluno!", ETipoMensagem.ERRO);
        }

        public IEnumerable<IGrouping<string, Aluno>> ObterDadosParaGraficoPorDataHora()
        {
            return alunoService.ObterDadosParaGraficoPorDataHora();
        }

        public List<KeyValuePair<string, List<Aluno>>> ObterDadosParaGraficoPorMunicipio()
        {
            return alunoService.ObterDadosParaGraficoPorMunicipio();
        }

        public JQGridResult<Aluno> ObterJQGrid(JQGrid jqGrid)
        {
            return alunoService.ObterJQGrid(jqGrid);
        }

        public JQGridResult<Aluno> ObterJQGridPorMunicipio(int id, JQGrid jqGrid)
        {
            return alunoService.ObterJQGridPorMunicipio(id, jqGrid);
        }
    }
}
