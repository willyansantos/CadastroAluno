﻿namespace Application.Logic.Autenticacao
{
    using Architecture;
    using Domain.Interfaces.Services.Autenticacao;
    using Domain.Entities.Autenticacao;
    using Domain.Entities.Enum;
    using static System.DateTime;
    using Domain.Util;
    using Domain.Interfaces.Application.Autenticacao;

    public class UsuarioApplicationService : ApplicationServiceBase<Usuario>, IUsuarioApplicationService
    {
        private readonly IUsuarioService usuarioService;

        public UsuarioApplicationService(IUsuarioService usuarioService)
        {
            this.usuarioService = usuarioService;
        }

        public void Inserir()
        {
            EstaValido = Entidade.ValidarInserir();

            if (!EstaValido)
            {
                AdicionarMensagens(Entidade.mensagens);
                return;
            }

            Entidade.Pessoa.DataCadastro = Now;
            Entidade.DataCadastro = Now;
            EstaValido = usuarioService.Inserir(Entidade);

            if (EstaValido)
                AdicionarMensagem("Usuario cadastrado com sucesso!", ETipoMensagem.SUCESSO);
            else
                AdicionarMensagem("Nao foi possivel cadastrar o usuario!", ETipoMensagem.ERRO);
        }

        public Usuario ObterPorCpfSenha(string cpf, string senha)
        {
            cpf = cpf.RemoveMascara();
            return usuarioService.ObterPorCpfSenha(cpf, senha);
        }
    }
}
