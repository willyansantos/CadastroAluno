﻿namespace Infra.Architecture
{
    using Domain.Interfaces.Repositories;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Data.Entity;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;

    public class RepositoryGeneric<E, C> : IDisposable, IRepositoryGeneric<E> where E : class, new() where C : DbContext, new()
    {
        protected IDbSet<E> dbSet;
        protected C context;

        protected RepositoryGeneric()
        {
            context = ContextManager.Getcontext<C>();
            dbSet = context.Set<E>();
            context.Configuration.LazyLoadingEnabled = true;
            context.Configuration.ProxyCreationEnabled = true;
        }

        public int ContarSomente(Expression<Func<E, bool>> where)
        {
            try
            {
                return dbSet.Where(where).Count();
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public void Dispose()
        {
            if (context != null)
                context.Dispose();
        }

        public bool Inserir(E entity)
        {
            dbSet.Add(entity);
            return SalvarAlteracoes();
        }

        public E Obter(Expression<Func<E, bool>> where)
        {
            try
            {
                return dbSet.Where(where).FirstOrDefault();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public IQueryable<E> ObterSomente(Expression<Func<E, bool>> where)
        {
            try
            {
                return dbSet.Where(where);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public IQueryable<E> ObterSomentePaginando(Expression<Func<E, bool>> where, string order, string typeorder, int startRowIndex, int maximumRows)
        {
            try
            {
                var query = dbSet.Where(where);
                query = query = typeorder == "asc" ? OrderBy(query, order) : OrderByDescending(query, order);
                return query.Skip(startRowIndex).Take(maximumRows);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public IQueryable<E> ObterTodos()
        {
            try
            {
                return dbSet;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public IQueryable<E> ObterTodosPaginando(string order, string typeorder, int startRowIndex, int maximumRows)
        {
            try
            {
                var query = dbSet.AsQueryable();
                query = typeorder == "asc" ? OrderBy(query, order) : OrderByDescending(query, order);
                return query.Skip(startRowIndex).Take(maximumRows);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private IQueryable<E> OrderBy(IQueryable<E> source, string orderBy)
        {
            return GetOrderByQuery(source, orderBy, "OrderBy");
        }
        private IQueryable<E> OrderByDescending(IQueryable<E> source, string orderBy)
        {
            return GetOrderByQuery(source, orderBy, "OrderByDescending");
        }
        private IQueryable<E> GetOrderByQuery(IQueryable<E> source, string orderBy, string methodName)
        {
            var sourceType = typeof(E);
            IList<PropertyInfo> props = new List<PropertyInfo>(sourceType.GetProperties());
            orderBy = orderBy ?? props.First().Name;
            PropertyInfo property = sourceType.GetProperty(orderBy);

            var parameterExpression = Expression.Parameter(sourceType, "x");
            var getPropertyExpression = Expression.MakeMemberAccess(parameterExpression, property);
            var orderByExpression = Expression.Lambda(getPropertyExpression, parameterExpression);
            var resultExpression = Expression.Call(typeof(Queryable), methodName, new[] { sourceType, property.PropertyType }, source.Expression, orderByExpression);

            return source.Provider.CreateQuery<E>(resultExpression);
        }

        protected bool SalvarAlteracoes()
        {
            try
            {
                context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
