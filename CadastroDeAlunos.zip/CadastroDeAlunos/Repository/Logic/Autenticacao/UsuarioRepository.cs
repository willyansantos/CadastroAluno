﻿namespace Infra.Logic.Autenticacao
{
    using Domain.Interfaces.Repositories.Autenticacao;
    using Architecture;
    using Domain.Entities.Autenticacao;

    public class UsuarioRepository : RepositoryGeneric<Usuario, CadastroAlunoEntities>, IUsuarioRepository
    {
    }
}
