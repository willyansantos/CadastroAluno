﻿namespace Infra.Logic.Cadastro
{
    using Domain.Interfaces.Repositories.Cadastro;
    using Architecture;
    using Logic;

    public class MunicipioRepository : RepositoryGeneric<Domain.Entities.Cadastro.Municipio, CadastroAlunoEntities>, IMunicipioRepository
    {
    }
}
