﻿namespace Infra.Logic.Cadastro
{
    using Domain.Interfaces.Repositories.Cadastro;
    using Architecture;
    using Logic;

    public class AlunoRepository : RepositoryGeneric<Domain.Entities.Cadastro.Aluno, CadastroAlunoEntities>, IAlunoRepository
    {
    }
}
